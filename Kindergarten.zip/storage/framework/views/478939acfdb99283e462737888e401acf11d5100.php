<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminLayout::class, []); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => 'Class']); ?>





  <div class="row justify-content-center">
    <div class="container">
      <div class="table-toolbar mb-3">
        <a href="<?php echo e(route('admin.user.create')); ?>" class="btn btn-info">Create</a>
      </div>
      <div class="row">


        <!-- course item -->
        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-4 col-sm-6 mb-5">
          <div class="card p-0 border-primary rounded-0 hover-shadow">
            <img class="card-img-top rounded-0" height="200" width="200" src="<?php echo e($user->image_url); ?>" alt="course thumb">
            <div class="card-body">
              <ul class="list-inline mb-2">
                <li class="list-inline-item"><i class="ti-calendar mr-1 text-color"></i></li>
                <li class="list-inline-item mr-4 mb-3 mb-sm-0">
                  <div class="d-flex align-items-center">
                    <i class="ti-alarm-clock text-primary icon-md mr-1"></i>

                </li>
              </ul>
              <a href="">
                <h4 class="card-title"><?php echo e($user->name); ?></h4>
              </a>
              <a href="">
                <h4 class="card-title d-inline"><?php $__currentLoopData = $user->claas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php echo e($class->seasons_name); ?>,
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </h4>
              </a>
              <div class="toolbar mt-3 mb-3">
                <a href="<?php echo e(route('admin.user.edit',[$user->id])); ?>" class="btn btn-sm btn-info">Edit</a>

                <form class="d-inline" action="<?php echo e(route('admin.user.destroy',[$user->id])); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('delete'); ?>
                  <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                </form>
              </div>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </div>

 <?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH D:\Kindergarten\resources\views/admin/teacher/index.blade.php ENDPATH**/ ?>