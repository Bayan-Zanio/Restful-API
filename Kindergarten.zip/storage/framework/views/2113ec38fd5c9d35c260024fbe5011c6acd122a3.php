<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminLayout::class, []); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => 'Class']); ?>


    <div class="row justify-content-center">

        <div class="container">

            <div class="row">
                <!-- course item -->

                <div class="col-lg-6 col-sm-6 mb-5">
                    <div class="card p-0 border-primary rounded-0 hover-shadow">
                        <a href="<?php echo e(route('admin.class.index')); ?>">
                            <img class="card-img-top rounded-0" height="200" width="200" src="<?php echo e(asset('images/h1.jpeg')); ?>" alt="course thumb">
                        </a>
                    </div>
                </div>

                <div class="col-lg-6 col-sm-6 mb-5">
                    <div class="card p-0 border-primary rounded-0 hover-shadow">
                        <a href="<?php echo e(route('admin.student.index')); ?>">
                            <img class="card-img-top rounded-0" height="200" width="200" src="<?php echo e(asset('images/h2.jpeg')); ?>" alt="course thumb">
                        </a>
                    </div>
                </div>

                <div class="col-lg-6 col-sm-6 mb-5">
                    <div class="card p-0 border-primary rounded-0 hover-shadow">
                        <a href="<?php echo e(route('admin.massage.massage')); ?>">
                            <img class="card-img-top rounded-0" height="200" width="200" src="<?php echo e(asset('images/h3.jpeg')); ?>" alt="course thumb">
                        </a>
                    </div>
                </div>

                <div class="col-lg-6 col-sm-6 mb-5">
                    <div class="card p-0 border-primary rounded-0 hover-shadow">
                        <a href="<?php echo e(route('admin.teacher.index')); ?>">
                            <img class="card-img-top rounded-0" height="200" width="200" src="<?php echo e(asset('images/h4.jpeg')); ?>" alt="course thumb">
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>


 <?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH D:\Kindergarten\resources\views/admin/home/index.blade.php ENDPATH**/ ?>