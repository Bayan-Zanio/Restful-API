<div class="form-group mb-3">
    <label for="">Name:</label>
    <input type="text" name="name" value="{{ old ('name',$user->name) }}" class="form-control @error('name') is-invlaid @enderror">
    @error('name')
    <p class="invalid-feedback d-block">{{ $message }}</p>
    @enderror
</div>


<div class="form-group mb-3">
    <label for="">email:</label>
    <input type="email" name="email" value="{{ old ('email',$user->email) }}" class="form-control @error('email') is-invlaid @enderror">
    @error('email')
    <p class="invalid-feedback d-block">{{ $message }}</p>
    @enderror
</div>


<div class="form-group mb-3">
    <label for="">password:</label>
    <input type="password" name="password" value="" class="form-control @error('password') is-invlaid @enderror">
    @error('password')
    <p class="invalid-feedback d-block">{{ $message }}</p>
    @enderror
</div>

<div class="form-group mb-3">
    <label for="">phone:</label>
    <input type="number" name="phone" value="{{ old ('phone',$user->phone) }}" class="form-control @error('phone') is-invlaid @enderror">
    @error('phone')
    <p class="invalid-feedback d-block">{{ $message }}</p>
    @enderror
</div>

<div class="form-group mb-3">
    <label for="">Class:</label>
    <select id="select" name="claas_id[]" class="form-control @error('claas_id') is-invlaid @enderror">
        <option value="">Select Class</option>
        @foreach ($claas as $class)
        <option value="{{$class->id}}" >{{ $class->seasons_name }}</option>
        @endforeach

    </select>
    @error('seasons_name')
    <p class="claas_id-feedback d-block">{{ $message }}</p>
    @enderror
</div>


<div class="form-group mb-3">
    <label for="">Image:</label>
    <div class="mb-2">
        <img src=" {{ $user->image_url }} " height="50" alt="">
    </div>
    <input type="file" name="image" class="form-control @error('image') is-invlaid @enderror">
    @error('image')
    <p class="invalid-feedback d-block">{{ $message }}</p>
    @enderror
</div>

<div class="form-group mb-3">
    <label for="">address:</label>
    <input type="text" name="address" value="{{ old ('address',$user->address) }}" class="form-control @error('address') is-invlaid @enderror">
    @error('address')
    <p class="invalid-feedback d-block">{{ $message }}</p>
    @enderror
</div>

<div class="form-group mb-3">
    <label for="">date_of_birth:</label>
    <input type="date" name="date_of_birth" value="{{ old ('date_of_birth',$user->date_of_birth) }}" class="form-control @error('date_of_birth') is-invlaid @enderror">
    @error('date_of_birth')
    <p class="invalid-feedback d-block">{{ $message }}</p>
    @enderror
</div>


<div class="form-group mb-3">
    <label for="">type:</label>
    <select name="type" class="form-control @error('type') is-invlaid @enderror">
        <option value="">Select type</option>
        <option value="student">Student</option>
        <option value="teacher">Teacher</option>

    </select>
    @error('type')
    <p class="invalid-feedback d-block">{{ $message }}</p>
    @enderror
</div>

<div class="form-group mb-3">
    <label for="">material:</label>
    <input type="text" name="material" value="{{ old ('material',$user->material) }}" class="form-control @error('material') is-invlaid @enderror">
    @error('material')
    <p class="invalid-feedback d-block">{{ $message }}</p>
    @enderror
</div>


<div class="form-group mb-3">
    <label for="">gender:</label>
    <select id="as" name="gender" class="form-control @error('gender') is-invlaid @enderror">
        <option value="">Select gender</option>
        <option value="male">male</option>
        <option value="female">female</option>

    </select>
    @error('gender')
    <p class="invalid-feedback d-block">{{ $message }}</p>
    @enderror
</div>

<div class="form-group">
    <button type="submit" class="btn btn-primary">{{ $button_label ?? 'Save' }}</button>
</div>

@push('script')
  <script>
    $(function() {
      $('select').selectize({maxItems: 3,});
    });
  </script>
  @endpush