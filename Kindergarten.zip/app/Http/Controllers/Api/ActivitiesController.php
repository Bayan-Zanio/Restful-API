<?php

namespace App\Http\Controllers\Api;

use App\Helpers\FCM;
use App\Http\Controllers\Controller;
use App\Models\Activities;
use App\Models\User;
use App\Models\UserDevice;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Response;

class ActivitiesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $activities =  Activities::with('images')->get();
        return response()->json($activities);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'seasons_name' => 'required',
            'name' => 'required',
            'activities_goal' => 'required',
            'duration' => 'required',
            'details' => 'required',
        ]);


        $activities = Activities::create($request->all());

        $activities->save();
        if ($request->hasFile('gallery')) {
            foreach ($request->file('gallery') as $file) {
                $image_path = $file->store('/images', [
                    'disk' => 'uploads'
                ]);

                // $image=new Images([
                //     'image_path'=>$image_path,
                // ]);
                $activities->Images()->create([
                    'image_path' => $image_path,
                ]);
            }
        }

        $activities->refresh();
        $users = User::whereHas('claas', function($query) use ($request){
            $query->where('claas_id', '=', $request);
        })->where('type','=','student')->get();
        
            //            $title = $labels['car_delivery'];
            //            $content =$message;

            $query = UserDevice::query();
            $user_fcm_tokens = $query->whereIn('user_id', $users)->where('status', 1)->pluck('fcm_token')->toArray();
            // $device_language = UserDevice::where('status', 1)->where('user_id', $activities->UserBooking->id)->first();
            // if ($device_language) {
            //     if ($device_language->lang == 'ar') {
            //         $title = 'تسليم السيارة';
            //         $content = 'تم تسليم السيارة بنجاح';
            //     } else {
            //         $title = 'car delivered';
            //         $content = 'car delivered successfully';
            //     }

            //     FCM::push($user_fcm_tokens, $title, $content);
            // }

            $title = 'نشاط جديد';
            $content = 'تم اضافة نشاط جديد';
            FCM::push($user_fcm_tokens, $title, $content);
        
        //return response()->json($product , 201);
        return Response::json($activities, 201);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return Activities::findOrFail($id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'seasons_name' => 'required',
            'name' => 'required',
            'activities_goal' => 'required',
            'duration' => 'required',
            'details' => 'required',
        ]);

        $activities = Activities::findOrFail($id);
        $activities->update($request->all());


        //return response()->json($product , 201);
        return Response::json([
            'message' => 'activities updated',
            'data' => $activities,
        ]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $user = Auth::guard('sanctum')->user();
        if (!$user->tokenCan('activities.create')) {
            return Response::json([
                'message' => 'Forbidden'
            ], 403);
        }


        $activities = Activities::findOrFail($id);
        $activities->delete();
        return Response::json([
            'message' => 'activities deleted',
            'data' => $activities,
        ]);
    }
}
